const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const tagsSchema = new Schema({ tags: 'string' });
const opts = {
    // Make Mongoose use Unix time (seconds since Jan 1, 1970)
    timestamps: { currentTime: () => Math.floor(Date.now() / 1000) },
};
let Product = new Schema({
    _id: {
        type: String
    },
    isActive: {
        type: String
    },
    price: {
        type: String
    },
    picture: {
        type: String
    },
    name: {
        type: String
    },
    about: {
        type: String
    },
    tags: {
        type: Array
    }

}, opts
);
module.exports = mongoose.model('Product', Product);

