module.exports = {
    'secret': '',
    'database': '127.0.0.1',
  };
