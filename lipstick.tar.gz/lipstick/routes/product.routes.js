let express = require('express');
let Product = require('../data/db/product.model');
productRoutes = express.Router();
let data = require("../server/data.js");

productRoutes.get('/migrate', function (req, res) {

  Product.deleteMany({});
    data.map(product => {
      //console.log(product)
      let prod = new Product({ name: product.name, _id: product._id, isActive: product.isActive, price: product.price, picture: product.picture, about: product.about, tags: product.tags });
  
      prod.save()
        .then(product => {
          console.log("Added ", product);
  
        })
        .catch(err => {
          console.log('adding new product failed')
        });
    })
    res.status(200).json({ 'product': 'imported products successfully' });
  });

productRoutes.get('/:term', (req, res) => {
  
  if (req.params.term.length > 2) {
    Product.find({ name: { $regex: req.params.term, $options: 'ig' } }, function (err, products) {
      //      if (err) return next(err);
      if (err) {
        console.log('ERROR')
      }
      if (!products.length) {
        res.json([]);
      } else {
        console.log(products)
        res.json(products);
      }
    });
  } else {
    res.json([]);
  }
});



productRoutes.get('/schema', function (req, res) {

  let schema = [];
  Product.schema.eachPath(function (path) {

    console.log('PATH', path);
    schema.push(path)

  });

  res.status(200).json({ schema });

});

module.exports = productRoutes;
