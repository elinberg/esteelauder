/**
 * This file will hold the Menu that lives at the top of the Page, this is all rendered using a React Component...
 * 
 */
import React from 'react';
import Autocomplete from '@mui/material/Autocomplete';
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import axios from 'axios';
class Menu extends React.Component {
    /**
     * Main constructor for the Menu Class
     * @memberof Menu
     */
    constructor(props) {
        super(props);
        this.state = {
            showingSearch: false,
            products: []
        };
        this.onChange = this.onChange.bind(this);
    }

    /**
     * Shows or hides the search container
     * @memberof Menu
     * @param e [Object] - the event from a click handler
     */
    showSearchContainer(e) {
        e.preventDefault();
        this.setState({
            showingSearch: !this.state.showingSearch,
            products: []
        });
    }

    /**
     * Calls upon search change
     * @memberof Menu
     * @param e [Object] - the event from a text change handler
     */
    onChange(e) {
        e.persist();
        // Start Here
        // ...
        axios.get('http://127.0.0.1:3035/products/' + e.target.value, {
            timeout: 5000,
            headers: {
                'xbmkey': 'key',
                'xbmname': 'apiName',
                'xbmsecret': 'secret'
            }
        })
            .then(response => {
                let prods = [];
                prods = response.data.map(x => x.name);
                console.log(prods);
                if (response.data.length < 1) {
                    prods = [];
                }
                this.setState({ products: prods })
            }).catch(function (error) {
                if (error.response) {
                    // The request was made and the server responded with a status code
                    // that falls out of the range of 2xx
                    console.log(error.response.data);
                    console.log(error.response.status);
                    console.log(error.response.headers);
                } else if (error.request) {
                    // The request was made but no response was received
                    // `error.request` is an instance of XMLHttpRequest in the browser and an instance of
                    // http.ClientRequest in node.js
                    this.setState({ products: [], showingSearch: !this.state.showingSearch })
                    console.log('The request was made but no response was received', error.request);
                } else {
                    // Something happened in setting up the request that triggered an Error
                    console.log('Error', error.message);
                }
                console.log(error.config);
            });

    }

    /**
     * Renders the default app in the window, we have assigned this to an element called root.
     * 
     * @returns JSX
     * @memberof App
    */

    render() {
        return (
            <header className="menu">
                <div className="menu-container">
                    <div className="menu-holder">
                        <h1>ELC</h1>
                        <nav>
                            <a href="#" className="nav-item">HOLIDAY</a>
                            <a href="#" className="nav-item">WHAT'S NEW</a>
                            <a href="#" className="nav-item">PRODUCTS</a>
                            <a href="#" className="nav-item">BESTSELLERS</a>
                            <a href="#" className="nav-item">GOODBYES</a>
                            <a href="#" className="nav-item">STORES</a>
                            <a href="#" className="nav-item">INSPIRATION</a>

                            <a href="#" onClick={(e) => this.showSearchContainer(e)}>
                                <i className="material-icons search">search</i>
                            </a>
                        </nav>
                    </div>
                </div>
                <div className={(this.state.showingSearch ? "showing " : "") + "search-container"}>
                <Autocomplete
                        id="combo-box-demo"
                        options={this.state.products}
                        filterOptions={(x) => x}
                        onChange={(e) => this.onChange(e)}
                        clearOnEscape
                        sx={{width: '95%'}}
                        renderInput={(params) => <TextField onChange={(e) => this.onChange(e)} {...params}  variant="standard">

                        </TextField>
                        }
                    />
                    <a href="#" onClick={(e) => this.showSearchContainer(e)}>
                        <i className="material-icons close">close</i>
                    </a>
                    
                    

                </div>
            </header>
        );
    }


}

// Export out the React Component
module.exports = Menu;
